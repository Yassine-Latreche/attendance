<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo e(mix('css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/select2-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/projectstyle.css')); ?>">

    <script src="<?php echo e(mix('js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(mix('js/qrcode.js')); ?>"></script>
    <script src="<?php echo e(mix('js/select2.min.js')); ?>"></script>

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;700&display=swap" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title'); ?> - <?php echo e(config('app.name')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(mix('js/momentjs.min.js')); ?>" defer></script>
    <script src="<?php echo e(mix('js/bootstrap.bundle.min.js')); ?>" defer></script>
    <script src="<?php echo e(mix('js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(mix('js/popper.min.js')); ?>" defer></script>
    <script>

        $.fn.select2.defaults.set("theme", "bootstrap");

    </script>
</head>

<body class="font-sans antialiased" style="background-color:#e2e2e2">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="min-h-screen ">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('dbCPY67')) {
    $componentId = $_instance->getRenderedChildComponentId('dbCPY67');
    $componentTag = $_instance->getRenderedChildComponentTagName('dbCPY67');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dbCPY67');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('dbCPY67', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <!-- Page Content -->
        <main style="
            margin-top: 75px;
            max-width: 70vw;
            margin-left: calc(10vw + 250px);
            margin-right: calc(10vw);">
            <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo e($slot); ?>

        </main>
    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH /opt/lampp/htdocs/attendance-2/resources/views/layouts/app.blade.php ENDPATH**/ ?>