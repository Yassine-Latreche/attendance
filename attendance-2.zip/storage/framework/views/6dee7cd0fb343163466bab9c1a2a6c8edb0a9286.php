<?php $__env->startSection('page-title'); ?>
Create Timetable
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <script src="<?php echo e(mix('js/getDetails.js')); ?>" defer></script>
  <script>
  $(function() {
    addtimetable();
    $("select").select2();
  });
  </script>
  <script src="/js/momentjs.min.js" ></script>
  <div style="
  padding: 20px;
  border-radius: 10px;
    background: #f3f3f3;
    margin-bottom: 25px">
    <div class="row" style="font-size: 2rem">
            <p>Timetables :</p>
        </div>
        <br>
  <table class="content-table" id="student_table" >
    <thead>
      <tr>
        <th style="width : 2rem;">Numero</th>
        <th>Module</th>
        <th>Professor</th>
        <th>Avec</th>
        <th style="width:2rem;">Type</th>
        <th style="width:2rem;">Jour</th>
        <th style="width:2rem;">Debut</th>
        <th style="width:2rem;">Fin</th>
        <th style="width:2rem;">Edit</th>
        <th style="width:2rem;">Delete</th>
      </tr>
    </thead>
    <tbody id="student_rows">
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><td><?php echo e($index + 1); ?></td>
            <td><?php echo e($row['module']); ?></td>
            <td><?php echo e($row['professor']); ?></td>
            <td><?php echo e($row['avec']); ?></td>
            <td><?php echo e($row['lecture_Type']); ?></td>
            <td><?php echo e($row['day_Of_Week']); ?></td>
            <td><?php echo e($row['starting']); ?></td>
            <td><?php echo e($row['ending']); ?></td>
            <td>
            <button type="button" class="btn btn-success material-icons" onclick="location.href='<?php echo e(url( 'teacher_dashboard/timetable/'.strval($row['id']))); ?>'">edit</button>
            </td>
            <td>
            <button type="button" class="btn btn-success material-icons" onclick="location.href='<?php echo e(url( 'teacher_dashboard/timetable/'.strval($row['id']).'/delete')); ?>'">delete</button>
            </td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
    <div style="
  padding: 20px;
  border-radius: 10px;
    background: #f3f3f3;">
    <div class="row" style="font-size: 2rem">
            <p>Add a timetable:</p>
            </div>
            <br>
            <form class="form" id="timetableForm" name="timetableForm" role="form" method="POST" >
                <?php echo csrf_field(); ?>
                  <div class="form-group form-group-lg">
                    <div class="row align-items-center">
                        <div class="col-1">
                            <label class="labels" for="module_Id">Module:</label>
                        </div>
                        <div class="col-2">
                            <select class="form-control input-lg" name="module_Id" id="module_Id">
                                <option disabled selected value="0">Module</option>
                            </select>
                        </div>
                        <div class="col-1">
                            <label class="labels" for="professor_Id">Professor:</label>
                        </div>
                        <div class="col-3">
                            <select class="form-control input-lg" name="professor_Id" id="professor_Id">
                                <option disabled selected value="0">Professor</option>
                            </select>
                        </div>
                        <div class="col-1">
                          <label class="labels" for="lecture_Type">Type:</label>
                        </div>
                        <div class="col-2">
                            <select class="form-control input-lg" name="lecture_Type" id="lecture_Type">
                              <option disabled selected value="0">Type</option>
                              <option value="cours">Cours</option>
                              <option value="TD">TD</option>
                              <option value="TP">TP</option>
                            </select>
                        </div>
                    </div>
                </div>
                <br>
                <div class="form-group form-group-lg">
                  <div class="row align-items-center">
                      <div class="col-1">
                          <label class="labels" for="level_Id">Level:</label>
                      </div>
                      <div class="col-2">
                          <select class="form-control input-lg" name="level_Id" id="level_Id">
                              <option disabled selected value="0">Level</option>
                          </select>
                      </div>
                      <div class="col-1">
                          <label class="labels" for="section_Id">Section:</label>
                      </div>
                      <div class="col-2">
                          <select class="form-control input-lg" name="section_Id" id="section_Id">
                              <option disabled selected value="0">Section</option>
                          </select>
                      </div>
                      <div class="col-1">
                        <label class="labels" for="group_Id">Group:</label>
                      </div>
                      <div class="col-2">
                          <select class="form-control input-lg" name="group_Id" id="group_Id">
                            <option disabled selected value="0">Group</option>
                            <option value="all">All</option>
                          </select>
                      </div>
                  </div>
               </div>
               <br>
               <div class="form-group form-group-lg">
                 <div class="row align-items-center">
                    <div class="col-1">
                        <label class="labels" for="day_Of_Week">Day:</label>
                    </div>
                    <div class="col-2">
                        <select class="form-control input-lg" name="day_Of_Week" id="day_Of_Week">
                          <option disabled selected value="0">Jour</option>
                          <option value="sunday">Sunday</option>
                          <option value="monday">Monday</option>
                          <option value="tuesday">Tuesday</option>
                          <option value="wednesday">Wednesday</option>
                          <option value="thursday">Thursday</option>
                          <option value="friday">Friday</option>
                          <option value="saturday">Saturday</option>
                        </select>
                    </div>
                    <div class="col-1">
                        <label class="labels" for="starting">Starting:</label>
                    </div>
                    <div class="col-2">
                      <input class="content__menu" type="time" id="starting" name="starting" value="">
                    </div>
                    <div class="col-1">
                      <label class="labels" for="ending">Ending:</label>
                    </div>
                    <div class="col-2">
                      <input class="content__menu" type="time" id="ending" name="ending" value="">
                    </div>
                 </div>
              </div>
              <br>
              <input class="confirm__button confirm__button--ok confirm__button--fill" type="submit" name="submit"
                  value="Add" />
            </form>
  </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/attendance-2/resources/views/crud/timetable/index.blade.php ENDPATH**/ ?>