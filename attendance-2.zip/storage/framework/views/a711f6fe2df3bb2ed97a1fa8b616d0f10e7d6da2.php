<?php $__env->startSection('page-title'); ?>
Scanning
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <script src="/js/momentjs.min.js" ></script>
    <div style="
  padding: 20px;
  border-radius: 10px;
    background: #f3f3f3;">
      <div id="time" style="font-size: 2.5rem">
        <div>
            <p style="display: inline !important" id="hours"></p>
            <p style="display: inline !important">:</p>
            <p style="display: inline !important" id="minutes"></p>
            <p style="display: inline !important">:</p>
            <p style="display: inline !important" id="seconds"></p>
            <p style="display: inline !important"> </p>
            <p style="display: inline !important" id="phase"></p>
        </div>
        <div>
            <p id="date"></p>
        </div>
      </div>
  </div>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg" style="    min-height: 650px; width: 650px;
          padding-bottom: 25px !important; margin: auto">
            <script>
              window.addEventListener("load", myInit, true); function myInit(){
              function nowtime(){
     var hours = document.getElementById("hours");
     var minutes = document.getElementById("minutes");
     var seconds = document.getElementById("seconds");
     var phase = document.getElementById("phase");
   
     var h = new Date().getHours();
     var m = new Date().getMinutes();
     var s = new Date().getSeconds();
     var am = "AM";
   
     if (h > 12) {
         h = h - 12;
         var am = "PM";
     }
   
     h = h < 10 ? "0" + h : h;
     m = m < 10 ? "0" + m : m;
     s = s < 10 ? "0" + s : s;
   
     hours.innerHTML = h;
     minutes.innerHTML = m;
     seconds.innerHTML = s;
     phase.innerHTML = am;
   
              }
                var date = document.getElementById("date");
  date.innerHTML = moment().format('dddd, MMMM Do YYYY');
  f2 = setInterval( nowtime()
    , 1000);
                      f1 = setInterval(function() {
                        nowtime()
                          $.post("/api/generate_qr_code",
                              {
                                  lecture_Id: <?php echo e($lecture_Id); ?>,
                              },
                              function(data, status){
                                  $('#qrcode').empty();
          
                                  // Set Size to Match User Input
                                  $('#qrcode').css({
                                  'width' : '600',
                                  'height' : '600',
                                  'margin-bottom': '10'
                                  })
          
                                  // Generate and Output QR Code
                                  $('#qrcode').qrcode({width: '600',height:'600',text: data+<?php echo e($lecture_Id); ?>});
          
                              });
                      }, 1000);
                  }
            </script>
            <input hidden type="number" class="qr-size" value="860" min="20" max="500">
                          
                  <br>
                  
                  <div style="
                      margin: auto;
                      
                  " id="qrcode" ></div>
          </div>
      </div>
  </div>
  <form name="summaryform" id="summaryform" action="<?php echo e(url("teacher_dashboard/summary")); ?>" method="GET">
    <input form="summaryform" hidden type="text" name="lecture_Id" id="lecture_Id" value="<?php echo e($lecture_Id); ?>">
  <input type="submit" id="btnChangeBg" class="material-icons floating-btn" style="font-size: 40px;" value="check_circle">
</form>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php /**PATH /opt/lampp/htdocs/attendance-2/resources/views/QRcodepage.blade.php ENDPATH**/ ?>