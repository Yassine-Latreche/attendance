<?php $__env->startSection('page-title'); ?>
Summary
<?php $__env->stopSection(); ?>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

  <script>
  function getDetails() {
            $.post('<?php echo e(url("/api/record/search")); ?>',
                {
                    lecture_Id: <?php echo e($lecture_Id); ?>,
                },
                function(data, status){
                    data.forEach((item, index) => {
                        $('#student_rows').append("<tr><td>"+item.student+"</td><td>"+item.section+"</td><td>"+item.group+"</td></tr>");
                    });                        
                });
            }  
  window.onload = function () {
      getDetails();
      function nowtime() {
        var hours = document.getElementById("hours");
    var minutes = document.getElementById("minutes");
    var seconds = document.getElementById("seconds");
    var phase = document.getElementById("phase");

    var h = new Date().getHours();
    var m = new Date().getMinutes();
    var s = new Date().getSeconds();
    var am = "AM";

    if (h > 12) {
        h = h - 12;
        var am = "PM";
    }

    h = h < 10 ? "0" + h : h;
    m = m < 10 ? "0" + m : m;
    s = s < 10 ? "0" + s : s;

    hours.innerHTML = h;
    minutes.innerHTML = m;
    seconds.innerHTML = s;
    phase.innerHTML = am;
      }
      nowtime();
      var date = document.getElementById("date");
    date.innerHTML = moment().format('dddd, MMMM Do YYYY');
    setInterval(function() {
       
    nowtime();
}, 1000);

}
</script>

    <div style="
  padding: 20px;
  border-radius: 10px;
    background: #f3f3f3;">
      <div id="time" style="font-size: 2.5rem">
        <div>
            <p style="display: inline !important" id="hours"></p>
            <p style="display: inline !important">:</p>
            <p style="display: inline !important" id="minutes"></p>
            <p style="display: inline !important">:</p>
            <p style="display: inline !important" id="seconds"></p>
            <p style="display: inline !important"> </p>
            <p style="display: inline !important" id="phase"></p>
        </div>
        <div>
            <p id="date"></p>
        </div>
      </div>
  </div>
<table class="content-table" id="student_table" style="    margin-top: 25px;
">
    <thead>
      <tr>
        <th>Student</th>
        <th>Section</th>
        <th>Group</th>
      </tr>
    </thead>
    <tbody id="student_rows">
      
    </tbody>
  </table>
  <div id="btnChangeBg" class="floating-btn" style="text-align:center;">
  <a href="<?php echo e(url("teacher_dashboard")); ?>" class="material-icons " style=" font-size: 40px;">home</a>
</div>
  
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/attendance-2/resources/views/summary.blade.php ENDPATH**/ ?>