<?php

namespace App\Http\Controllers;
use App\Models\Team;
use App\Models\User;

use Illuminate\Http\Request;
use Auth;
class TestController extends Controller
{
    public function index() {
        $user = Auth::user();
        // dd(Team::where('name', 'SuperUsers')->first());
        print($user->belongsToTeam(Team::where('name', 'SuperUsers')->first()));
        echo "<br>Test Controller.";
     }
}
