function getDetails() {
    $.get("/api/timetable",
        function (data, status) {
            data.forEach((timetableItem, index) => {
                var g_or_s = '';
                if (timetableItem.is_In_Group == '1') {
                    $.get("/api/group/" + timetableItem.group_Id,
                        function (groupdata, status) {
                            g_or_s = "Group " + groupdata.group;
                        });
                } else {
                    $.get("/api/section/" + timetableItem.section_Id,
                        function (sectiondata, status) {
                            g_or_s = "Section " + sectiondata.section;
                        });
                }
                $.get("/api/module/" + timetableItem.module_Id,
                    function (datamodule, status) {
                        $('#timetable').append('<option value="' + timetableItem.id + '">' +
                            datamodule.module + '  |  ' + timetableItem.lecture_Type + '  |  ' +
                            g_or_s + '</option>');
                    });
            });
        });


    $(function () {
        $("#timetable").select2();
    });
}
function addtimetable() {
    $.get("/api/module",
        function (datamodule, status) {
            datamodule.forEach(element => {
                $('#module_Id').append('<option value="' + element.id + '">' +
                    element.module + '</option>');
            });
        });

    $.get("/api/professor",
        function (dataprofessor, status) {
            dataprofessor.forEach(element => {
                $('#professor_Id').append('<option value="' + element.id + '">' +
                    element.name + '</option>');
            });
        });
    $.get("/api/level",
        function (data, status) {
            data.forEach((levelItem, index) => {
                $('#level_Id').append('<option value="' + levelItem.id + '">' +
                    levelItem.level + '</option>');
            });
        }
    );

    $("#level_Id").on("input", function () {
        $('#group_Id').empty().append('<option selected disabled value="0">Group</option>').append('<option value="all">All</option>');
        $('#section_Id').empty().append('<option selected disabled value="0">Section</option>');
        $.get("/api/level/"+$("#level_Id").val()+'/section',
            function (data, status) {
                data.forEach((sectionItem, index) => {
                    $('#section_Id').append('<option value="' + sectionItem.id + '">' +
                    sectionItem.section + '</option>');
                    console.log('1');
                });
                console.log('gg');
            }
        );
    });

    $("#section_Id").on("input", function () {
        $('#group_Id').empty().append('<option selected disabled value="0">Group</option>').append('<option value="all">All</option>');
        $.get("/api/level/"+$("#level_Id").val()+'/section/'+$("#section_Id").val()+'/group',
            function (data, status) {
                data.forEach((groupItem, index) => {
                    $('#group_Id').append('<option value="' + groupItem.id + '">' +
                    groupItem.group + '</option>');
                });
            }
        );
    });

    
}

function edittimetable(module_Id, professor_Id, lecture_Type, level_Id, section_Id, group_Id, day_Of_Week) {
    $.get("/api/module",
        function (datamodule, status) {
            datamodule.forEach(element => {
                $('#module_Id').append('<option value="' + element.id + ((module_Id == element.id) ?'" selected' : '"') + '>' +
                    element.module + '</option>');
            });
        });

    $.get("/api/professor",
        function (dataprofessor, status) {
            dataprofessor.forEach(element => {
                $('#professor_Id').append('<option value="' + element.id + ((professor_Id == element.id) ? '" selected' : '"') + '>' +
                    element.name + '</option>');
            });
        }
    );
    
    var lecture_Types =[
        {
            'type' : 'Cours',
            'id' : 'cours'
        },
        {
            'type' : 'TD',
            'id' : 'TD'
        },
        {
            'type' : 'TP',
            'id' : 'TP'
        },
    ];

    lecture_Types.forEach(element => {
        $('#lecture_Type').append('<option value="' + element.id + ((lecture_Type == element.id )? '" selected' : '"') + '>' +
            element.type + '</option>');
    });

    var days_Of_Week = [
        {
            'day' : 'Sunday',
            'id' : 'sunday'
        },
        {
            'day' : 'Monday',
            'id' : 'monday'
        },
        {
            'day' : 'Tuesday',
            'id' : 'tuesday'
        },
        {
            'day' : 'Wednesday',
            'id' : 'wednesday'
        },
        {
            'day' : 'Thursday',
            'id' : 'thursday'
        },
        {
            'day' : 'Friday',
            'id' : 'friday'
        },
        {
            'day' : 'Saturday',
            'id' : 'saturday'
        },
    ];

    days_Of_Week.forEach(element => {
        $('#day_Of_Week').append('<option value="' + element.id + ((day_Of_Week == element.id) ? '" selected' : '"') + '>' +
            element.day + '</option>');
    });

    $.get("/api/level",
        function (data, status) {
            data.forEach((levelItem, index) => {
                $('#level_Id').append('<option value="' + levelItem.id + ((level_Id == levelItem.id) ? '" selected' : '"') +  '>' +
                    levelItem.level + '</option>');
            });
            $('#section_Id').empty().append('<option disabled value="0">Section</option>');
            $.get("/api/level/"+$("#level_Id").val()+'/section',
                function (data, status) {
                    data.forEach((sectionItem, index) => {
                        $('#section_Id').append('<option ' + ((section_Id == sectionItem.id) ? 'selected' : '') + ' value="' + sectionItem.id +'"' + '>' +
                        sectionItem.section + '</option>');
                    });
                    console.log(data);
                    $('#group_Id').empty().append('<option disabled value="0">Group</option>');
                    $.get("/api/level/"+$("#level_Id").val()+'/section/'+$("#section_Id").val()+'/group',
                        function (data, status) {
                            data.forEach((groupItem, index) => {
                                $('#group_Id').append('<option value="' + groupItem.id + ((group_Id == groupItem.id) ? '" selected' : '"') + '>' +
                                groupItem.group + '</option>');
                            });
                        }
                    );
                }
            ); 
        }
    ); 

    $("#level_Id").on("input", function () {
        $('#group_Id').empty().append('<option selected disabled value="0">Group</option>').append('<option value="all">All</option>');
        $('#section_Id').empty().append('<option selected disabled value="0">Section</option>');
        $.get("/api/level/"+$("#level_Id").val()+'/section',
            function (data, status) {
                data.forEach((sectionItem, index) => {
                    $('#section_Id').append('<option value="' + sectionItem.id + '">' +
                    sectionItem.section + '</option>');
                });
            }
        );
    });

    $("#section_Id").on("input", function () {
        $('#group_Id').empty().append('<option selected disabled value="0">Group</option>').append('<option value="all">All</option>');
        $.get("/api/level/"+$("#level_Id").val()+'/section/'+$("#section_Id").val()+'/group',
            function (data, status) {
                data.forEach((groupItem, index) => {
                    $('#group_Id').append('<option value="' + groupItem.id + '">' +
                    groupItem.group + '</option>');
                });
            }
        );
    });
    


}